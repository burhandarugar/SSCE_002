package com.jap.dayfinder;

public class DayFinder {
//The current day of week is taken in int (For Sunday 1, Monday 2, Tuesday 3....Saturday 7)
    public String predictDay(int currentDay, int noOfDaysFromToday)
    {
       int result=(currentDay+Math.abs(noOfDaysFromToday))%7 ;
       String out="";
       switch(result)
       {
        case 1: out="Sunday";
               break;
        case 2: out="Monday";
               break;
        case 3: out="Tuesday";
               break;
        case 4: out="Wednesday";
               break;
        case 5: out="Thursday";
               break;
        case 6: out="Friday";
               break;
        case 7: out="Saturday";
               break;
       }
       
       return out;
    }

    public static void main(String[] args)
    {
        DayFinder dayFinder = new DayFinder();
        int medicineTakenOn = 2;
        int daysToNextDose =  -7;
        String nextDoseToBeTakenOn = dayFinder.predictDay(medicineTakenOn,daysToNextDose);
        System.out.println("Your next dose should be taken on :  "+nextDoseToBeTakenOn);
    }

}
