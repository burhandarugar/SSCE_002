## Seed code - Boilerplate


### Instructions


Refer to the PROBLEM.md file for the problem description.


#### To use this as a boilerplate for your assignment, please follow the below step.


1. **FORK** the repository in your Gitlab account.



